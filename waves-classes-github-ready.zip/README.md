# WAVES CLASSES

Website starter for Classes 9–12.

## Files
- `index.html` — homepage
- `admin-login.html` — admin login landing page
- `student-login.html` — student login landing page
- `parent-login.html` — parent login landing page
- `.nojekyll` — GitHub Pages configuration

## Publish with GitHub Pages
1. Create or open your GitHub repository.
2. Upload all files in this folder to the repository's top level (root).
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then Save.
6. Wait for deployment and open the site URL shown in Pages settings.

GitHub Pages serves static files only. These pages are a front-end starter; real admin/student/parent authentication, database, fee management, and attendance require a secure backend such as Firebase. Do not put passwords, student records, API secrets, or private data in this public repository.
